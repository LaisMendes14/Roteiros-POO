using System;

// CLASSE PARA O EXERCÍCIO 2
public class CarroR02
{
    private int _velocidadeAtual;

    public string Modelo { get; } 

    public int VelocidadeAtual
    {
        get { return _velocidadeAtual; }
        private set 
        {
            _velocidadeAtual = Math.Max(0, value); 
        }
    }

    public CarroR02(string modelo)
    {
        Modelo = modelo;
        VelocidadeAtual = 0; 
    }

    public void Acelerar(int valor)
    {
        if (valor > 0)
        {
            VelocidadeAtual += valor; 
            Console.WriteLine($"Acelerou em {valor} km/h. Nova velocidade: {VelocidadeAtual} km/h.");
        }
    }

    public void Frear(int valor)
    {
        if (valor > 0)
        {
            int novaVelocidade = VelocidadeAtual - valor;
            if (novaVelocidade < 0 && VelocidadeAtual > 0)
            {
                Console.WriteLine($"Freou bruscamente. Velocidade limitada a 0 km/h.");
            }
            VelocidadeAtual = novaVelocidade;
        }
    }
}
