using System;

// CLASSE PARA O EXERCÍCIO 3
public class ElevadorR02
{
    private int _andarAtual;

    public int TotalAndares { get; } 

    public int AndarAtual
    {
        get { return _andarAtual; }
        private set 
        {
            if (value < 0) _andarAtual = 0;
            else if (value > TotalAndares) _andarAtual = TotalAndares;
            else _andarAtual = value;
        }
    }

    public ElevadorR02(int totalAndares)
    {
        TotalAndares = totalAndares;
        AndarAtual = 0;
    }

    public void Subir()
    {
        if (AndarAtual < TotalAndares)
        {
            AndarAtual++;
            Console.WriteLine($"Subiu. Andar atual: {AndarAtual}");
        }
        else
        {
            Console.WriteLine("Já está no último andar. Não pode subir mais.");
        }
    }

    public void Descer()
    {
        if (AndarAtual > 0)
        {
            AndarAtual--;
            Console.WriteLine($"Desceu. Andar atual: {AndarAtual}");
        }
        else
        {
            Console.WriteLine("Já está no Térreo (Andar 0). Não pode descer mais.");
        }
    }
}
