using System;

// CLASSE PARA O EXERCÍCIO 1
public class ProdutoR02
{
    private decimal _preco;

    public string Nome { get; private set; } 

    public decimal Preco
    {
        get { return _preco; }
        set
        {
            if (value >= 0)
            {
                _preco = value;
            }
            else
            {
                Console.WriteLine("⚠️ Erro: O preço não pode ser negativo. Valor não alterado.");
            }
        }
    }

    public ProdutoR02(string nome, decimal preco)
    {
        Nome = nome; 
        Preco = preco;
    }

    public void ExibirDetalhes()
    {
        Console.WriteLine($"Produto: {Nome} | Preço: R$ {Preco:N2}");
    }
}
