using System;

// CLASSES ABSTRATAS (EXERCÍCIO 2)
public abstract class FuncionarioR04
{
    public string Nome { get; set; }
    public decimal SalarioBase { get; set; }

    public FuncionarioR04(string nome, decimal salarioBase)
    {
        Nome = nome;
        SalarioBase = salarioBase;
    }

    public abstract decimal CalcularSalario();

    public void ExibirInformacoes()
    {
        Console.Write($"{Nome} ({GetType().Name}) | Salário Líquido: R$ ");
    }
}

public class GerenteR04 : FuncionarioR04
{
    public GerenteR04(string nome, decimal salarioBase) : base(nome, salarioBase) { }
    public override decimal CalcularSalario()
    {
        return SalarioBase * 1.20m;
    }
}

public class ProgramadorR04 : FuncionarioR04
{
    public ProgramadorR04(string nome, decimal salarioBase) : base(nome, salarioBase) { }
    public override decimal CalcularSalario()
    {
        return SalarioBase * 0.90m;
    }
}
