using System;

// POLIMORFISMO DE PAGAMENTO (EXERCÍCIO 1)
public class PagamentoR04
{
    public virtual void ProcessarPagamento()
    {
        Console.WriteLine("Pagamento: Iniciando processamento genérico...");
    }
}

public class CartaoCreditoR04 : PagamentoR04
{
    public override void ProcessarPagamento()
    {
        Console.WriteLine("Cartão de Crédito: Verificando limite, comunicando à operadora e processando débito.");
    }
}

public class BoletoBancarioR04 : PagamentoR04
{
    public override void ProcessarPagamento()
    {
        Console.WriteLine("Boleto Bancário: Gerando PDF e registrando na CIP. Prazo de 3 dias para compensação.");
    }
}

public class PixR04 : PagamentoR04
{
    public override void ProcessarPagamento()
    {
        Console.WriteLine("Pix: Gerando chave de pagamento e confirmando a transferência instantânea.");
    }
}
