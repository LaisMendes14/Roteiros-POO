using System;
using System.Collections.Generic;

public class ExercicioLista
{
    public static void Executar()
    {
        List<string> listaCompras = new List<string>();
        string acao = "";
        while (acao != "S")
        {
            Console.WriteLine("\nOpções: [A]dicionar, [R]emover, [L]istar, [S]air");
            Console.Write("Ação: ");
            acao = Console.ReadLine().ToUpper();

            if (acao == "A")
            {
                Console.Write("Item: ");
                listaCompras.Add(Console.ReadLine());
            }
            else if (acao == "R")
            {
                Console.Write("Item a remover: ");
                if (!listaCompras.Remove(Console.ReadLine()))
                    Console.WriteLine("Item não encontrado.");
            }
            else if (acao == "L")
            {
                Console.WriteLine($"--- LISTA ({listaCompras.Count} itens) ---");
                listaCompras.ForEach(item => Console.WriteLine($"- {item}"));
            }
        }
    }
}
