using System;
using System.Collections.Generic;

public class ExercicioDicionario
{
    public static void Executar()
    {
        Dictionary<int, string> catalogo = new Dictionary<int, string>();
        string acao = "";
        while (acao != "S")
        {
            Console.WriteLine("\nOpções: [A]dicionar, [B]uscar, [L]istar, [S]air");
            Console.Write("Ação: ");
            acao = Console.ReadLine().ToUpper();

            if (acao == "A")
            {
                Console.Write("Código (int): ");
                if (!int.TryParse(Console.ReadLine(), out int codigo) || catalogo.ContainsKey(codigo))
                {
                    Console.WriteLine("Código inválido ou duplicado.");
                    continue;
                }
                Console.Write("Nome: ");
                catalogo.Add(codigo, Console.ReadLine());
            }
            else if (acao == "B")
            {
                Console.Write("Código para buscar: ");
                if (int.TryParse(Console.ReadLine(), out int codigoBusca) && catalogo.TryGetValue(codigoBusca, out string nome))
                {
                    Console.WriteLine($"Produto: {nome}");
                }
                else
                {
                    Console.WriteLine("Produto não encontrado.");
                }
            }
            else if (acao == "L")
            {
                Console.WriteLine("--- CATÁLOGO ---");
                foreach (var par in catalogo)
                    Console.WriteLine($"Cód: {par.Key} | Nome: {par.Value}");
            }
        }
    }
}
