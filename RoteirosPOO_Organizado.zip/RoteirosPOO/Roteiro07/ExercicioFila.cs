using System;
using System.Collections.Generic;

public class ExercicioFila
{
    public static void Executar()
    {
        Queue<string> filaClientes = new Queue<string>();
        string acao = "";
        while (acao != "S")
        {
            Console.WriteLine($"\nFila atual: {filaClientes.Count}");
            Console.WriteLine("Opções: [A]dicionar, [T]rabalhar/Atender, [S]air");
            Console.Write("Ação: ");
            acao = Console.ReadLine().ToUpper();

            if (acao == "A")
            {
                Console.Write("Nome: ");
                filaClientes.Enqueue(Console.ReadLine());
            }
            else if (acao == "T")
            {
                if (filaClientes.Count > 0)
                {
                    Console.WriteLine($"Atendendo: {filaClientes.Dequeue()}");
                }
                else
                {
                    Console.WriteLine("Fila vazia.");
                }
            }
        }
    }
}
