using System;
using System.Windows.Forms;

public partial class Form1 : Form
{
    // Variáveis para movimentação da tela (Header)
    private bool drag = false;
    private int mouseX = 0, mouseY = 0;

    public Form1()
    {
        InitializeComponent();
    }

    // Movimentação da tela
    private void panelHeader_MouseDown(object sender, MouseEventArgs e)
    {
        drag = true;
        mouseX = Cursor.Position.X - this.Left;
        mouseY = Cursor.Position.Y - this.Top;
    }

    private void panelHeader_MouseMove(object sender, MouseEventArgs e)
    {
        if (drag)
        {
            this.Top = Cursor.Position.Y - mouseY;
            this.Left = Cursor.Position.X - mouseX;
        }
    }

    private void panelHeader_MouseUp(object sender, MouseEventArgs e)
    {
        drag = false;
    }

    // Funções de Janela
    private void btnClose_Click(object sender, EventArgs e)
    {
        this.Close();
    }

    // Ex. 1: Maximizar e Minimizar
    private void btnMaximizar_Click(object sender, EventArgs e)
    {
        if (this.WindowState == FormWindowState.Normal)
        {
            this.WindowState = FormWindowState.Maximized;
        }
        else
        {
            this.WindowState = FormWindowState.Normal;
        }
    }

    private void btnMinimizar_Click(object sender, EventArgs e)
    {
        this.WindowState = FormWindowState.Minimized;
    }

    // Ex. 2: Abertura de Forms Filhas
    private void AbrirFormFilha(Form formFilha)
    {
        formFilha.TopLevel = false;
        formFilha.Dock = DockStyle.Fill;
        this.Controls.Add(formFilha); 
        formFilha.BringToFront();
        formFilha.Show();
    }

    // Ex. 2: Botão Clientes
    private void btnClientes_Click(object sender, EventArgs e)
    {
        AbrirFormFilha(new FormClientes());
    }
    // Implementar funções similares para os demais botões (Produtos, Pedidos, etc.)
}

public class FormClientes : Form
{
    // Form filho de exemplo
}
