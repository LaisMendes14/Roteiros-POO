using System;

// CLASSE PARA O EXERCÍCIO 1
public class FuncionarioR01
{
    public string Nome;
    public int Idade;
    public string Cargo; // Atributo Adicional

    public void Apresentar()
    {
        Console.WriteLine($"Olá, meu nome é {Nome}, tenho {Idade} anos e meu cargo é {Cargo}.");
    }

    public void InformarSalario()
    {
        decimal salario;

        switch (Cargo)
        {
            case "Gerente":
                salario = 10000.00m;
                break;
            case "Desenvolvedor":
                salario = 5000.00m;
                break;
            case "Estagiário":
                salario = 100.00m;
                break;
            default:
                salario = 0.00m;
                break;
        }

        Console.WriteLine($"O salário de um {Cargo} (Funcionário: {Nome}) é de R$ {salario:N2}.");
    }
}
