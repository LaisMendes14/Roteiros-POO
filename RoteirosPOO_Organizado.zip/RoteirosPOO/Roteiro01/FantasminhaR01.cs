using System;

// CLASSE PARA O EXERCÍCIO 2
public class FantasminhaR01
{
    public string Habilidade;
    public string Nick;
    public string Cor;

    public void GerarFantasma()
    {
        Console.WriteLine("--- Fantasminha Gerado ---");
        Console.WriteLine($"Nick: {Nick}");
        Console.WriteLine($"Cor: {Cor}");
        Console.WriteLine($"Habilidade: {Habilidade}");
    }

    public void Mover(string direcao)
    {
        Console.WriteLine($"{Nick} se moveu para **{direcao}**!");
    }
}
