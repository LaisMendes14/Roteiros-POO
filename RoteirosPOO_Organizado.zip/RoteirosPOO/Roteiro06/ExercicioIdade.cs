    using System;

    public class IdadeInvalidaException : Exception
    {
        public IdadeInvalidaException(string mensagem) : base(mensagem) { }
    }

    public class ExercicioIdade
    {
        public static void VerificarIdade(int idade)
        {
            if (idade < 18)
            {
                throw new IdadeInvalidaException("Idade mínima para acesso é 18 anos.");
            }
            else
            {
                Console.WriteLine("Acesso permitido.");
            }
        }

        public static void Executar()
        {
            Console.Write("Digite a idade: ");
            try
            {
                int idade = int.Parse(Console.ReadLine());
                VerificarIdade(idade);
            }
            catch (FormatException)
            {
                Console.WriteLine("Erro: Formato de idade inválido.");
            }
            catch (IdadeInvalidaException ex)
            {
                Console.WriteLine($"
Erro: {ex.Message}");
            }
        }
    }
