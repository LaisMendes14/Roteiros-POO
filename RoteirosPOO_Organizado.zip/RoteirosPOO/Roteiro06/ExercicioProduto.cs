    using System;

    public class ExercicioProduto
    {
        public static void Executar()
        {
            Console.Write("Digite o nome do produto: ");
            string nome = Console.ReadLine();

            Console.Write("Digite o preço do produto: ");
            decimal preco;
            bool precoValido = decimal.TryParse(Console.ReadLine(), out preco);

            try
            {
                if (string.IsNullOrWhiteSpace(nome))
                {
                    throw new ArgumentException("O nome do produto não pode estar em branco.");
                }
                if (!precoValido || preco <= 0)
                {
                    throw new ArgumentException("O preço do produto deve ser um valor positivo.");
                }
                Console.WriteLine($"
Produto cadastrado: {nome} (R$ {preco:N2})");
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine($"
Erro de Validação: {ex.Message}");
            }
        }
    }
