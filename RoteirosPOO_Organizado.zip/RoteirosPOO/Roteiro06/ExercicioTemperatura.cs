    using System;

    public class ExercicioTemperatura
    {
        public static float ConverterParaCelsius(string input)
        {
            return float.Parse(input);
        }

        public static void Executar()
        {
            bool entradaValida = false;
            while (!entradaValida)
            {
                Console.Write("Digite a temperatura em Celsius: ");
                string input = Console.ReadLine();

                try
                {
                    float temperatura = ConverterParaCelsius(input);
                    entradaValida = true;
                    Console.WriteLine($"
Temperatura registrada: {temperatura:F1}°C");
                }
                catch (FormatException)
                {
                    Console.WriteLine("Erro: A entrada não é um número válido. Tente novamente.");
                }
            }
        }
    }
