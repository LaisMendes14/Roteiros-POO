using System;
using System.Windows.Forms;
using Npgsql;
using System.Collections.Generic;

namespace WinFormsPostgres
{
    public partial class Form1 : Form
    {
        private string connString =
            "Host=localhost;Username=postgres;Password=123456;Database=exemplo_db";
        private List<int> listaIds = new List<int>();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text;
            string sobrenome = txtSobrenome.Text;

            if (string.IsNullOrWhiteSpace(nome))
            {
                MessageBox.Show("Digite o nome.");
                return;
            }

            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    // Adiciona sobrenome
                    string insertSql = "INSERT INTO usuarios (nome, sobrenome) VALUES (@nome, @sobrenome)";
                    using (var cmd = new NpgsqlCommand(insertSql, conn))
                    {
                        cmd.Parameters.AddWithValue("nome", nome);
                        cmd.Parameters.AddWithValue("sobrenome", (object)(sobrenome ?? string.Empty));
                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Usuário salvo com sucesso!");
                txtNome.Clear();
                txtSobrenome.Clear();
                btnListar_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao salvar: {ex.Message}");
            }
        }

        private void btnListar_Click(object sender, EventArgs e)
        {
            listUsuarios.Items.Clear();
            listaIds.Clear();

            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    // Seleciona ID, nome e sobrenome
                    string sql = "SELECT id, nome, sobrenome FROM usuarios ORDER BY id";
                    using (var cmd = new NpgsqlCommand(sql, conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int id = reader.GetInt32(0);
                            string nome = reader.GetString(1);
                            string sobrenome = reader.IsDBNull(2) ? "" : reader.GetString(2);

                            // Listar nome completo
                            string nomeCompleto = $"{nome} {sobrenome}".Trim();

                            listUsuarios.Items.Add(nomeCompleto);
                            listaIds.Add(id); // Armazena o ID
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao listar: {ex.Message}");
            }
        }

        // Excluir usuário selecionado
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            int indiceSelecionado = listUsuarios.SelectedIndex;

            if (indiceSelecionado == -1)
            {
                MessageBox.Show("Selecione um usuário para excluir.");
                return;
            }

            if (MessageBox.Show(
                    "Deseja realmente excluir?",
                    "Confirmação",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning) == DialogResult.No)
            {
                return;
            }

            int idExcluir = listaIds[indiceSelecionado];

            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string deleteSql = "DELETE FROM usuarios WHERE id = @id";
                    using (var cmd = new NpgsqlCommand(deleteSql, conn))
                    {
                        cmd.Parameters.AddWithValue("id", idExcluir);
                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show($"Usuário excluído (ID: {idExcluir}).");
                btnListar_Click(null, null); // Atualiza a lista
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao excluir: {ex.Message}");
            }
        }
    }
}
