using System;

// HERANÇA (EXERCÍCIO 1)
public class AnimalR03
{
    public string Nome { get; set; } 
    public virtual void EmitirSom()
    {
        Console.WriteLine($"{Nome}: Som genérico do animal.");
    }
}

public class CachorroR03 : AnimalR03
{
    public override void EmitirSom()
    {
        Console.WriteLine($"{Nome}: Au Au!");
    }
}
