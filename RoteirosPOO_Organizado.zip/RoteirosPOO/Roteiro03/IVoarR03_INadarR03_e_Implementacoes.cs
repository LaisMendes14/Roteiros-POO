using System;

// MÚLTIPLAS INTERFACES (EXERCÍCIO 4)
public interface IVoarR03 { void Voar(); }
public interface INadarR03 { void Nadar(); }

public class PatoR03 : IVoarR03, INadarR03
{
    public void Voar() { Console.WriteLine("Pato: Estou voando com as asas."); }
    public void Nadar() { Console.WriteLine("Pato: Estou nadando com as patas."); }
}

public class AguiaR03 : IVoarR03 { public void Voar() { Console.WriteLine("Águia: Estou voando bem alto."); } }
public class PeixeR03 : INadarR03 { public void Nadar() { Console.WriteLine("Peixe: Estou nadando com as barbatanas."); } }
