using System;

// INTERFACE IVEICULO (EXERCÍCIO 3)
public interface IVeiculoR03
{
    void Mover(); 
}

public class VeiculoCarroR03 : IVeiculoR03
{
    public void Mover()
    {
        Console.WriteLine("O carro está se movendo (motorizado).");
    }
}

public class BicicletaR03 : IVeiculoR03
{
    public void Mover()
    {
        Console.WriteLine("A bicicleta está se movendo (propulsão humana).");
    }
}
