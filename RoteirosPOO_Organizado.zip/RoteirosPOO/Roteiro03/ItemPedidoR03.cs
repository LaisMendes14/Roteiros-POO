using System;

// COMPOSIÇÃO (EXERCÍCIO 2)
public class ItemPedidoR03
{
    public string Descricao { get; set; }
    public int Quantidade { get; set; }
    public decimal PrecoUnitario { get; set; }
    public decimal SubTotal => Quantidade * PrecoUnitario;

    public void ExibirDetalhes()
    {
        Console.WriteLine($"  - Item: {Descricao} | Qtd: {Quantidade} | Preço: R$ {PrecoUnitario:N2}");
    }
}
