using System;

public class PedidoR03
{
    private ItemPedidoR03 _item;
    public int NumeroPedido { get; set; }

    public PedidoR03(int numero, string itemDescricao, int qtd, decimal preco)
    {
        NumeroPedido = numero;
        _item = new ItemPedidoR03
        {
            Descricao = itemDescricao,
            Quantidade = qtd,
            PrecoUnitario = preco
        };
    }

    public void MostrarResumo()
    {
        Console.WriteLine($"\n--- Resumo do Pedido #{NumeroPedido} ---");
        _item.ExibirDetalhes();
        Console.WriteLine($"Total do Item: R$ {_item.SubTotal:N2}");
    }
}
