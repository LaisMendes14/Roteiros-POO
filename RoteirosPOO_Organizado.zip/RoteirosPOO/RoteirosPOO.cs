using System;
using System.Collections.Generic;
using System.Linq;

public class RoteirosPOO
{
    public static void Main(string[] args)
    {
        Console.WriteLine("=================================================");
        Console.WriteLine("   ROTEIROS DE AULA POO - CÓDIGO CONSOLIDADO  ");
        Console.WriteLine("=================================================");


        // --- ROTEIRO 01: CLASSE, ATRIBUTOS E MÉTODOS ---
        Console.WriteLine("\n\n--- ROTEIRO 01: EXEMPLOS DE CLASSES E MÉTODOS ---");

        // Ex. 1: Funcionário
        FuncionarioR01 gerente = new FuncionarioR01 { Nome = "João Silva", Idade = 45, Cargo = "Gerente" };
        gerente.InformarSalario();

        // Ex. 2: Fantasminha
        FantasminhaR01 blinky = new FantasminhaR01 { Nick = "Blinky", Cor = "Vermelho" };
        blinky.GerarFantasma();
        blinky.Mover("Esquerda");


        // --- ROTEIRO 02: ENCAPSULAMENTO ---
        Console.WriteLine("\n\n--- ROTEIRO 02: ENCAPSULAMENTO E VALIDAÇÕES ---");

        // Ex. 1: Produto (Teste de validação de preço)
        ProdutoR02 p = new ProdutoR02("Monitor", 800m);
        p.Preco = -100m; // Falha na validação
        p.ExibirDetalhes();

        // Ex. 3: Elevador (Teste de limite)
        ElevadorR02 e = new ElevadorR02(5);
        e.Subir();
        e.Descer();
        e.Descer(); // Limite inferior (0)


        // --- ROTEIRO 03: HERANÇA, COMPOSIÇÃO E INTERFACES ---
        Console.WriteLine("\n\n--- ROTEIRO 03: HERANÇA, COMPOSIÇÃO E INTERFACES ---");

        // Ex. 1: Herança (Animal)
        CachorroR03 rexR3 = new CachorroR03 { Nome = "Rex" };
        rexR3.EmitirSom();

        // Ex. 2: Composição (Pedido)
        PedidoR03 pedido = new PedidoR03(101, "Teclado Mecânico", 1, 350.00m);
        pedido.MostrarResumo();

        // Ex. 4: Múltiplas Interfaces (Pato)
        PatoR03 patoR3 = new PatoR03();
        patoR3.Voar();
        patoR3.Nadar();


        // --- ROTEIRO 04: POLIMORFISMO E CLASSES ABSTRATAS ---
        Console.WriteLine("\n\n--- ROTEIRO 04: POLIMORFISMO E CLASSES ABSTRATAS ---");

        // Ex. 1: Polimorfismo de Pagamento
        List<PagamentoR04> lista = new List<PagamentoR04>
        {
            new CartaoCreditoR04(),
            new PixR04()
        };
        foreach (var pag in lista)
        {
            pag.ProcessarPagamento(); // Polimorfismo
        }

        // Ex. 2: Classes Abstratas (Cálculo de Salário)
        GerenteR04 gR4 = new GerenteR04("Ana", 8000m);
        gR4.ExibirInformacoes();
        Console.WriteLine($"{gR4.CalcularSalario():N2}");

        // Demais roteiros (05-09) podem ser chamados manualmente:
        // ExercicioMath.Executar();
        // ExercicioString.Executar();
        // ExercicioDataFormatacao.Executar();
        // ExercicioProduto.Executar();
        // ExercicioTemperatura.Executar();
        // ExercicioIdade.Executar();
        // ExercicioLista.Executar();
        // ExercicioDicionario.Executar();
        // ExercicioFila.Executar();
    }
}
