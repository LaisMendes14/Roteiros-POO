    using System;
    using System.Linq;

    public class ExercicioString
    {
        public static void Executar()
        {
            Console.Write("Digite uma frase com espaços extras e separada por vírgulas: ");
            string fraseOriginal = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(fraseOriginal)) return;

            string fraseTrim = fraseOriginal.Trim();
            Console.WriteLine($"
[1] Trim(): '{fraseTrim}'");

            string[] partes = fraseTrim
                .Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(p => p.Trim())
                .ToArray();

            Console.WriteLine($"[2] Split(): {string.Join(" | ", partes)}");

            if (partes.Length > 0)
            {
                string palavraAntiga = partes[0];
                string fraseReplace = fraseTrim.Replace(palavraAntiga, "NOVA_PALAVRA");
                Console.WriteLine($"[3] Replace(): '{fraseReplace}'");
            }

            string comecaCom = "O";
            Console.WriteLine($"[4] StartsWith('{comecaCom}'): {fraseTrim.StartsWith(comecaCom, StringComparison.OrdinalIgnoreCase)}");

            string terminaCom = "FIM";
            Console.WriteLine($"[5] EndsWith('{terminaCom}'): {fraseTrim.EndsWith(terminaCom, StringComparison.OrdinalIgnoreCase)}");
        }
    }
