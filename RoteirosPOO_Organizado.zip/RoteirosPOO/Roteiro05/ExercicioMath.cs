    using System;

    public class ExercicioMath
    {
        public static void Executar()
        {
            double[] numeros = new double[5];

            for (int i = 0; i < 5; i++)
            {
                Console.Write($"Digite o {i + 1}º número decimal: ");
                if (double.TryParse(Console.ReadLine(), out double inputNum))
                {
                    numeros[i] = inputNum;
                }
                else
                {
                    numeros[i] = 0.0;
                }
            }

            foreach (double num in numeros)
            {
                Console.WriteLine($"
Original: {num}");
                Console.WriteLine($"  Math.Round: {Math.Round(num)}");
                Console.WriteLine($"  Math.Floor: {Math.Floor(num)}");
                Console.WriteLine($"  Math.Ceiling: {Math.Ceiling(num)}");
                Console.WriteLine($"  Math.Truncate: {Math.Truncate(num)}");
            }
        }
    }
