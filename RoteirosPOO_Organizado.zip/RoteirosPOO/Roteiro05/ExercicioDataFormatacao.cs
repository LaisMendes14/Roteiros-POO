using System;

public class ExercicioDataFormatacao
{
    public static void Executar()
    {
        Console.Write("Digite seu nome: ");
        string nome = Console.ReadLine();

        Console.Write("Digite a data e hora do compromisso (dd/MM/yyyy HH:mm): ");
        string dataInput = Console.ReadLine();

        DateTime dataCompromisso;
        if (!DateTime.TryParseExact(
                dataInput,
                "dd/MM/yyyy HH:mm",
                null,
                System.Globalization.DateTimeStyles.None,
                out dataCompromisso))
        {
            dataCompromisso = DateTime.Now.AddDays(5);
        }

        TimeSpan diferenca = dataCompromisso - DateTime.Now;
        int diasFaltando = (int)Math.Ceiling(diferenca.TotalDays); 

        string culturaOriginal = System.Threading.Thread.CurrentThread.CurrentCulture.Name;
        System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("pt-BR");
        string diaDaSemana = dataCompromisso.ToString("dddd");
        System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo(culturaOriginal);

        string mensagem = string.Format(
            "Olá, {0}!\nSeu compromisso será em {1} dia(s), na {2}.\nData marcada: {3:dd/MM/yyyy} às {3:HH:mm}",
            nome,
            diasFaltando,
            diaDaSemana,
            dataCompromisso
        );

        Console.WriteLine("\n--- MENSAGEM FINAL FORMATADA ---");
        Console.WriteLine(mensagem);
    }
}
